import { StyleSheet } from "react-native";

const StyleIndicator = StyleSheet.create({
  Indicador: {
    margin: 20,
    justifyContent: "center",
    marginTop: 50,
  },
});

export default StyleIndicator;
