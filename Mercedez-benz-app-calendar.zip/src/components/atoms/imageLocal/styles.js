import { StyleSheet } from "react-native";

const styles = StyleSheet.create({
  img: {

  },
});

export default styles;
